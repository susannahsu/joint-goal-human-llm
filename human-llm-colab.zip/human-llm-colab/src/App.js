// import React from 'react';
// import Chat from './Chat';
// import WebsitePreview from './WebsitePreview';
// import './App.css';


// function App() {
//   return (
//     <div className="App">
//       <div className="container">
//         {/* Chat */}
//         <div className="chat-section">
//           <Chat />
//         </div>

//         {/* Website Preview */}
//         <div className="website-preview-section">
//           <WebsitePreview />
//         </div>

//         {/* Scratch Pad */}
//         <div className="scratch-pad-section">
//           <h2>Scratch Pad</h2>
//         </div>
//       </div>
//     </div>
//   );
// }

// export default App;

import React, { useState } from 'react';
import Chat from './Chat';
import WebsitePreview from './WebsitePreview';  // Initial default component
import './App.css';

function App() {
  const [websiteScript, setWebsiteScript] = useState(null); // State for dynamically rendering new scripts

  return (
    <div className="App">
      <div className="container">
        {/* Chat */}
        <div className="chat-section">
          <Chat setWebsiteScript={setWebsiteScript} /> {/* Pass the handler */}
        </div>

        {/* Website Preview */}
        <div className="website-preview-section">
          {websiteScript ? (
            // Dynamically inject the new script as JSX
            <div dangerouslySetInnerHTML={{ __html: websiteScript }} />
          ) : (
            <WebsitePreview /> // Render the default WebsitePreview.js initially
          )}
        </div>
      </div>
    </div>
  );
}

export default App;
